Per seguire l'applicativo è necessario avere la versione jdk-17.
Gli step da eseguire per aprire il codice sorgente in netbeans,e farlo funzionare, sono:
	- Creare un progetto maven per java fx in NetBeans;
	- Sostituire la cartella "src" creata automaticamente da NetBeans con "Source-Gruppo03/src"
	- Sostituire il pom, sempre creato automaticamente da NetBeans, con il file "pom.xml" riportato in questa stessa cartella "Source-Gruppo03".

Questo è il procedimento che ha funzionato sulle nostre macchine (Windows x1, Fedora Linux x1, MacOS x2), ma questa è solo una linea guida. 